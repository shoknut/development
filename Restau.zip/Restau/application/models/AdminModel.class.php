<?php
 class AdminModel{
    function delete(){

    }
 }
<?php
// chaque page est une classe objet PHP
class PaymentController
{
    // $queryFields = $_GET
    /**
     * @param Http $http
     * @param array $queryFields
     */
    public function httpGetMethod(Http $http, array $queryFields)
    {



    }

    public function httpPostMethod(Http $http, array $formFields){



    }


}
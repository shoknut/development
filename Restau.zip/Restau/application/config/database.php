<?php

/*
 * Database configuration settings used by PDO.
 */

$config['dsn']      = 'mysql:host=localhost;dbname=restaurant';
$config['password'] = 'troiswa';
$config['user']     = 'root';